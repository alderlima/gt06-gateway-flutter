package com.example.gt06_gateway

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
